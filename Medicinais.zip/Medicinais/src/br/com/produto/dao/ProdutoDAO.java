package br.com.produto.dao;

import br.com.produto.conexao.ConexaoProduto;
import br.com.medicinais.model.ProdutoModel;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ProdutoDAO {

    public void CreateProduto(ProdutoModel produtoModel) {

        String sql = "INSERT INTO produto (nome,descricao,data_compra,fornecedor,preco,estoque) VALUES (?,?,?,?,?,?)";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {

            connection = ConexaoProduto.ConexaoSQL();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, produtoModel.getNome());
            preparedStatement.setString(2, produtoModel.getDescricao());
            preparedStatement.setString(3, produtoModel.getData_compra());
            preparedStatement.setString(4, produtoModel.getFornecedor());
            preparedStatement.setDouble(5, produtoModel.getPreco());
            preparedStatement.setInt(6, produtoModel.getEstoque());

            preparedStatement.execute();

        } catch (Exception e) {

            System.out.println("Erro cadastro produtos: " + e);

        }

    }

    public List<ProdutoModel> ShowProduto() {

        String sql = "SELECT * FROM produto";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        ArrayList<ProdutoModel> produtos = new ArrayList<>();
        //classe que vai recuperar os dados do banco.
        ResultSet resultSet = null;

        try {

            connection = ConexaoProduto.ConexaoSQL();
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                ProdutoModel produtoss = new ProdutoModel();

                produtoss.setId_produto(resultSet.getInt("id_produto"));
                produtoss.setNome(resultSet.getString("nome"));
                produtoss.setDescricao(resultSet.getString("descricao"));
                produtoss.setData_compra(resultSet.getString("data_compra"));
                produtoss.setFornecedor(resultSet.getString("fornecedor"));
                produtoss.setPreco(resultSet.getDouble("preco"));
                produtoss.setEstoque(resultSet.getInt("estoque"));

                produtos.add(produtoss);

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return produtos;
    }

    public void UpdateProduto(ProdutoModel produtoModel) {

        String sql = "UPDATE produto SET nome = ?,descricao = ?,data_compra = ?,fornecedor=?,preco= ?,estoque=? WHERE id_produto=?";

        Connection connection = null;
        PreparedStatement ps = null;

        try {
            connection = ConexaoProduto.ConexaoSQL();
            ps = connection.prepareStatement(sql);

            ps.setString(1, produtoModel.getNome());
            ps.setString(3, produtoModel.getDescricao());
            ps.setString(4, produtoModel.getData_compra());
            ps.setString(5, produtoModel.getDescricao());
            ps.setString(6, produtoModel.getFornecedor());

            ps.setDouble(7, produtoModel.getPreco());
            ps.setInt(8, produtoModel.getEstoque());

            ps.execute();

            JOptionPane.showMessageDialog(null, "produto atualizado com sucesso");

        } catch (Exception e) {
            System.out.println("Erro:  " + e);
        }
    }

    public void DeleteProduto(int id_produto) {

        String sql = "DELETE FROM produto WHERE id_produto = ?";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = ConexaoProduto.ConexaoSQL();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id_produto);

            preparedStatement.execute();

        } catch (Exception e) {
            System.out.println("Erro " + e);
        }

    }

}
